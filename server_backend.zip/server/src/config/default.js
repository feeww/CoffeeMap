export default {
    port: 4000,
    allowedOrigins: ["*"]
};
